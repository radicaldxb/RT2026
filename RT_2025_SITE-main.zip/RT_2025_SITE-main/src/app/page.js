// src/app/page.js
import Home from './home'

export default function Page() {
  return <Home />
}
